This codeplex project is the revival of good old .NET Webservice Studio tool. Its objective is to adds the support for WCF, Nullable Types and REST style API to allow a complete composite type testing from one tool.

Web Service Studio is a tool to invoke webmethods interactively. The user can provide a WSDL endpoint. On clicking button Get the tool fetches the WSDL, generates .NET proxy from the WSDL and displays the list of methods available. The user can choose any method and provide the required input parameters. On clicking Invoke the SOAP request is sent to the server and the response is parsed to display the return value.

This tool is meant for webservice implementers to test their webservices without having to write the client code. This could also be used to access other webservices whose WSDL endpoint is known. 


![](Home_wsstudioscreenshot.jpg)

Adapted from Original Implementation by  sowmys AT Microsoft