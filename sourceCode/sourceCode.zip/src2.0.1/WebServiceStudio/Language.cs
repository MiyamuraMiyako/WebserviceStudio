﻿namespace WebServiceStudio
{
    using System;

    public enum Language
    {
        CS,
        VB,
        Custom
    }
}

