﻿// Assembly WebServiceStudio, Version 0.0.0.0

[assembly: System.Reflection.AssemblyVersion("0.0.0.0")]
[assembly: System.Diagnostics.Debuggable(false, true)]

